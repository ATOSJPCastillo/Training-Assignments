package com.myapp;

import com.myapp.model.Products;


import com.myapp.model.User;
import com.myapp.repository.UserRepository;

public class InvokeApp {

	public static void main(String[] args) {

		try {
			UserRepository userrepository = new UserRepository();
			if (userrepository.authenticate("raul@gmail.com", "password@123123drink")) {
				System.out.println("Welcome user");
				User u = new User();
				u.setEmployeeId(3456);
				u.setEmployeeName("vara");
				u.setEmail("vara@gmail.com");
				u.setEmpPassword("pass12345meme");
				u.setRole_type("traitor123");
				u.setDeptname("dartnet");
				
			if(userrepository.add(u)) {
					u = userrepository.getByEmail(u.getEmail());
				System.out.println("Name: " + u.getEmployeeName() + " Email: "+ u.getEmail());
				}				
			} 

		} 
		
		catch (Exception e) {
			System.out.println("problem in connecting to db ");			
		}

	}

}
