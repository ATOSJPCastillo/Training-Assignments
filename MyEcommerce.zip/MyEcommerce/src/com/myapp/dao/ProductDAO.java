package com.myapp.dao;

import com.myapp.model.Products;

public interface ProductDAO {
	Products getByName(String productName);
	boolean add(Products products);
	boolean delete(int productId);
}
