package com.myapp.model;

import java.util.HashMap;
import com.myapp.valid.Validator;

public class Products extends Validator {

	private int productId;
	private String productName;
	private float productPrice;
	
	public Products() {		
		errorMessage=new HashMap<String,String>();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public float getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}

	public Products(int productId, String productName, float productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	
}
