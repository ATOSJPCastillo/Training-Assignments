package com.myapp.test;

import static org.junit.Assert.assertEquals;


import java.sql.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.myapp.model.User;
import com.myapp.repository.UserRepository;

public class UserRepositoryTest {
	UserRepository userrepository;

	@Before
	public void setUp() {
		userrepository = new UserRepository();
	}

	@Test
    public void delateUserTest() {
        userrepository= new UserRepository();
        assertEquals("Failed to delete the user!", true, userrepository.delete(1266));
    }
	
	@After
	public void tearDown() throws Exception {
	}

		
/*	
	@Test
	public void testDBConnection() {
		String url= "jdbc:oracle:thin:localhost:1521:xe" ;
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "hr", "password");
			System.out.println("We are connected to the db");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT EMPLOYEEID,EMPLOYEENAME FROM hr.userinfo");
			while (rs.next()) {
				String employee_id = rs.getString("employeeid");
				String employee_name = rs.getString("employeename");
				System.out.println(employee_id + " " + employee_name);
				}			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	
		@Test
		public void addUserTest() {
			User user = new User();
			user.setEmployeeId(123123);
			user.setEmployeeName("Raul");
			user.setDeptname("DEPTY");
			user.setEmail("raul@gmail.com");
			user.setRole_type("Traitor");
			user.setEmpPassword("password@123123drink");
			assertEquals("Failed to add the user!", true, userrepository.add(user));
		}	

	@Test
	public void testDBConnection() {
		String url= "jdbc:oracle:thin:localhost:1521:xe" ;
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "hr", "password");
			System.out.println("We are connected to the db");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT EMPLOYEEID,EMPLOYEENAME FROM hr.userinfo");
			while (rs.next()) {
				String employee_id = rs.getString("employeeid");
				String employee_name = rs.getString("employeename");
				System.out.println(employee_id + " " + employee_name);
				}			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	// failed-negative test case

	@Test
	public void testFailAuthUserFail() {
		assertEquals("Failed to validate the user!", true,
				userrepository.authenticate("chhaya.nikam@gmail.com", "password"));
	}

	// positive test case
	@Ignore
	@Test
	public void testAuthUser() {
		assertEquals("Failed to validate the user!", true,
				userrepository.authenticate("chhaya.nikam@nt.com", "password"));
	}

	@Test
	public void testAuthUser() {
		assertEquals("Failed to validate the user!", true,
				userrepository.authenticate("raul@gmail.com", "password@123123drink"));
	}
	

	// negative test case
	@Ignore
	@Test
	public void addUserTestFail() {
		User user = new User();
		user.setEmployeeId(18776);
		user.setEmployeeName("Riya");
		user.setDeptname("CEB");
		user.setEmail("riya@gmail.com.com");
		user.setRole_type("Trainer");
		user.setEmpPassword("password@123");
		assertEquals("Failed to add the user!", true, userrepository.add(user));
	}
	
	
	@Ignore
	
	@Test	
	public void updateUserTest1() {		
		User euser=new User();		
		euser.setEmployeeName("Riya");
		euser.setDeptname("CEB");
		euser.setEmail("riya@gmail.com");
		euser.setRole_type("Trainerasdf");
		euser.setEmpPassword("password@123123");
		assertEquals("Failed to update the user!", true, userrepository.update(euser));
		System.out.println("successfully Updated");
		
		}

	

*/
}
