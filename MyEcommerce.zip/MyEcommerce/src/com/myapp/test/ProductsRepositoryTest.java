package com.myapp.test;

import java.sql.*;

import static org.junit.Assert.assertEquals;


import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.myapp.model.Products;
import com.myapp.repository.ProductRepository;
import com.myapp.repository.UserRepository;

public class ProductsRepositoryTest {
	ProductRepository productrepository;
	
	
	@Before
	public void setUp() {
		productrepository = new ProductRepository();
	}

	@Test
	public void add() {
		ProductRepository productRepository=new ProductRepository();
		Products product = new Products();
		product.setProductId(69420);
		product.setProductName("labalaba");
		product.setProductPrice(25000.00f);
		assertEquals("Failed to add the user!", true, productrepository.add(product));
	}
	
//	@Test
//    public void delateUserTest() {
//        productrepository= new ProductRepository();
//        assertEquals("Failed to delete the user!", true, productrepository.delete(12112));
//        System.out.println("User Deleted");
//    }
	
	@After
	public void tearDown() throws Exception{
		
	}
	
	/*
	 * 
@Test
	public void testDBConn() {
		String url= "jdbc:oracle:thin:localhost:1521:xe" ;
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "hr", "password");
			System.out.println("Successfully Connected");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(
					"select productid, prodname from hr.products");
			while(rs.next()) {
				String prod_id = rs.getString("productid");
				String prod_name = rs.getString("prodname");
				System.out.println("Records: ");
				System.out.println(prod_id +" "+prod_name);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
			
		}
	}
	 */
	
	
	
}
