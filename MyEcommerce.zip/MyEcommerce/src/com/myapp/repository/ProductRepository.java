package com.myapp.repository;

import java.sql.*;

import com.myapp.dao.ProductDAO;
import com.myapp.db.DbConnect;
import com.myapp.model.Products;

public class ProductRepository implements ProductDAO {
	DbConnect db;
	Connection conn;
	
	public ProductRepository() {
		db = new DbConnect();
		conn = db.getConnection();
	}
	
	@Override
	public Products getByName(String productName) {
		// TODO Auto-generated method stub
		Products products = new Products();
		String query = "select * from products where prodname=?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, productName);
			ResultSet rs = pstmt.executeQuery();
			if(!rs.next()) {
				return null;
			}
			else {
				products.setProductId(rs.getInt(1));
				products.setProductPrice(rs.getFloat(3));
				products.setProductName(rs.getString(2));
				
				return products;
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	
	
	@Override
	public boolean add(Products products) {
		// TODO Auto-generated method stub
		try {
			Connection conn = db.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"INSERT INTO Products (productid, prodname, prodprice)" + " values (?, ?, ?)");
			pstmt.setInt(1, products.getProductId());
			pstmt.setString(2, products.getProductName());
			pstmt.setFloat(3, products.getProductPrice());
			pstmt.executeUpdate();
			conn.close();
			System.out.println("Product Added");
			return true;	
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean delete(int productId) {
		// TODO Auto-generated method stub
		try {
			Connection conn = db.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"DELETE from products where productid=?");
			pstmt.setInt(1, productId);
			pstmt.executeUpdate();
			conn.close();
			return true;
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}



}
